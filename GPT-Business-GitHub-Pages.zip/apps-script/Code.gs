const SHEETS = {
  roots: ["id","name","email","billingDay","expiry","capacity","status","memo"],
  children: ["id","rootId","name","email","status","memo"],
  guests: ["id","name","email","organization","rootId","courseId","start","end","removedAt","memo"],
  courses: ["id","title","start","end","required","assigned","rootId","manager","status","memo"]
};

function doGet(e) {
  try { return json_({ok:true, data:readAll_()}); }
  catch (error) { return json_({ok:false, error:String(error)}); }
}

function doPost(e) {
  const lock = LockService.getScriptLock();
  try {
    lock.waitLock(10000);
    const body = JSON.parse(e.postData.contents || "{}");
    if (body.action !== "saveAll" || !body.data) throw new Error("Invalid request");
    validate_(body.data);
    Object.keys(SHEETS).forEach(key => writeSheet_(key, body.data[key] || []));
    writeSettings_(body.data.settings || {});
    return json_({ok:true});
  } catch (error) { return json_({ok:false, error:String(error)}); }
  finally { lock.releaseLock(); }
}

function setup() {
  Object.keys(SHEETS).forEach(key => writeSheet_(key, []));
  writeSettings_({ownerUsesSeat:true});
}

function readAll_() {
  const data = {};
  Object.keys(SHEETS).forEach(key => data[key] = readSheet_(key));
  data.settings = readSettings_();
  return data;
}

function readSheet_(name) {
  const sheet = getSheet_(name);
  const values = sheet.getDataRange().getValues();
  if (values.length < 2) return [];
  const headers = values[0];
  return values.slice(1).filter(row => row[0] !== "").map(row => Object.fromEntries(headers.map((h,i) => [h, normalize_(row[i])])));
}

function writeSheet_(name, rows) {
  const sheet = getSheet_(name), headers = SHEETS[name];
  sheet.clearContents();
  sheet.getRange(1,1,1,headers.length).setValues([headers]).setFontWeight("bold").setBackground("#dcece2");
  if (rows.length) sheet.getRange(2,1,rows.length,headers.length).setValues(rows.map(row => headers.map(h => row[h] ?? "")));
  sheet.setFrozenRows(1);
}

function getSheet_(name) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  return ss.getSheetByName(name) || ss.insertSheet(name);
}

function writeSettings_(settings) {
  const sheet = getSheet_("settings");
  sheet.clearContents();
  sheet.getRange(1,1,2,2).setValues([["key","value"],["ownerUsesSeat",String(settings.ownerUsesSeat !== false)]]);
}

function readSettings_() {
  const sheet = getSheet_("settings"), rows = sheet.getDataRange().getValues().slice(1);
  const values = Object.fromEntries(rows.filter(r => r[0]).map(r => [r[0], r[1]]));
  return {ownerUsesSeat:String(values.ownerUsesSeat) !== "false"};
}

function validate_(data) {
  ["roots","children","guests","courses"].forEach(k => { if (!Array.isArray(data[k])) throw new Error(`${k} must be an array`); });
  const ids = data.roots.map(r => r.id);
  if (new Set(ids).size !== ids.length) throw new Error("Duplicate root id");
  data.guests.forEach(g => { if (g.end < g.start) throw new Error("Guest end date is invalid"); });
}

function normalize_(value) {
  if (value instanceof Date) return Utilities.formatDate(value, Session.getScriptTimeZone(), "yyyy-MM-dd'T'HH:mm");
  return value;
}

function json_(value) {
  return ContentService.createTextOutput(JSON.stringify(value)).setMimeType(ContentService.MimeType.JSON);
}
